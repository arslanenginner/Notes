// void main() {
//   print('Hello world');

//   var firstname = 'ahmad';
//   String secname = 'ahsan';
//   print(firstname + ' ' + secname);
//}

import 'dart:core';
import 'dart:io';

main() {
  stdout.writeln("What is your name?");
  String? name = stdin.readLineSync();
  print('My name is $name');
}

int m1 = 200;
var m2 = 300;

print('m1: $am1 | m2: $am2 \n');

double  m3=29.1
var 